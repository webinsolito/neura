package main

import (
	"path/filepath"
	"testing"
)

func TestEffectCommittedReplayDoesNotReexecute(t *testing.T) {
	j, e := OpenEffectJournal(filepath.Join(t.TempDir(), "effects.json"))
	if e != nil {
		t.Fatal(e)
	}
	r, replay, e := j.ClaimEffect("send-1", map[string]any{"to": "a"})
	if e != nil || replay {
		t.Fatalf("claim %v %v", replay, e)
	}
	if _, e = j.CommitEffect("send-1", r.ClaimToken, "ok"); e != nil {
		t.Fatal(e)
	}
	r2, replay, e := j.ClaimEffect("send-1", map[string]any{"to": "a"})
	if e != nil || !replay || r2.Result != "ok" {
		t.Fatalf("replay=%v result=%q err=%v", replay, r2.Result, e)
	}
}
func TestEffectCrashWindowRequiresReconciliation(t *testing.T) {
	p := filepath.Join(t.TempDir(), "effects.json")
	j, e := OpenEffectJournal(p)
	if e != nil {
		t.Fatal(e)
	}
	if _, _, e = j.ClaimEffect("mut-1", map[string]any{"x": 1}); e != nil {
		t.Fatal(e)
	}
	j2, e := OpenEffectJournal(p)
	if e != nil {
		t.Fatal(e)
	}
	if _, _, e = j2.ClaimEffect("mut-1", map[string]any{"x": 1}); e == nil || e.Error() != "effect_uncertain_reconcile_required" {
		t.Fatalf("got %v", e)
	}
}
func TestEffectSameKeyDifferentPayloadDenied(t *testing.T) {
	j, _ := OpenEffectJournal(filepath.Join(t.TempDir(), "effects.json"))
	if _, _, e := j.ClaimEffect("k", map[string]any{"x": 1}); e != nil {
		t.Fatal(e)
	}
	if _, _, e := j.ClaimEffect("k", map[string]any{"x": 2}); e == nil || e.Error() != "effect_idempotency_conflict" {
		t.Fatalf("got %v", e)
	}
}
func TestEffectWrongClaimTokenDenied(t *testing.T) {
	j, _ := OpenEffectJournal(filepath.Join(t.TempDir(), "effects.json"))
	r, _, _ := j.ClaimEffect("k", map[string]any{"x": 1})
	if _, e := j.CommitEffect("k", r.ClaimToken+"bad", "ok"); e == nil || e.Error() != "effect_claim_token_mismatch" {
		t.Fatalf("got %v", e)
	}
}
