//go:build !linux && !windows

package main

import "errors"

func detectSystemMemoryBytes() (uint64, error) {
	return 0, errors.New("memory detection unsupported on this OS")
}
func detectFreeDiskBytes(path string) (uint64, error) {
	return 0, errors.New("disk detection unsupported on this OS")
}
