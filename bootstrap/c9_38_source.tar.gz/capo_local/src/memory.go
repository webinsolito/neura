package main

import (
	"encoding/json"
	"errors"
	"fmt"
	"net/http"
	"os"
	"path/filepath"
	"sort"
	"strings"
	"time"
	"unicode"
)

type MemoryFact struct {
	ID            string  `json:"id"`
	Topic         string  `json:"topic"`
	Text          string  `json:"text"`
	Source        string  `json:"source"`
	Confidence    float64 `json:"confidence"`
	Reinforcement int     `json:"reinforcement"`
	CreatedAt     string  `json:"created_at"`
	UpdatedAt     string  `json:"updated_at"`
	Active        bool    `json:"active"`
	SupersededBy  string  `json:"superseded_by,omitempty"`
	SupersededAt  string  `json:"superseded_at,omitempty"`
	ForgottenAt   string  `json:"forgotten_at,omitempty"`
}

type MemoryState struct {
	Version int          `json:"version"`
	Facts   []MemoryFact `json:"facts"`
}

type MemoryTeachRequest struct {
	Topic      string  `json:"topic"`
	Text       string  `json:"text"`
	Source     string  `json:"source"`
	Confidence float64 `json:"confidence"`
}

type MemoryForgetRequest struct {
	Topic string `json:"topic"`
}

type MemoryEvent struct {
	Kind       string `json:"kind"`
	Topic      string `json:"topic"`
	FactID     string `json:"fact_id,omitempty"`
	PreviousID string `json:"previous_id,omitempty"`
	Note       string `json:"note,omitempty"`
}

func (s *Server) memoryStatePath() string {
	return filepath.Join(s.rootDir, "capo_data", "memory_state.json")
}

func (s *Server) memoryAuditPath() string {
	return filepath.Join(s.rootDir, "capo_data", "MEMORY.md")
}

func normalizeTopic(topic string) string {
	topic = strings.ToLower(strings.TrimSpace(topic))
	var b strings.Builder
	lastSpace := false
	for _, r := range topic {
		if unicode.IsLetter(r) || unicode.IsDigit(r) || r == '-' || r == '_' {
			b.WriteRune(r)
			lastSpace = false
		} else if unicode.IsSpace(r) || r == '/' || r == ':' || r == '.' {
			if !lastSpace && b.Len() > 0 {
				b.WriteByte(' ')
				lastSpace = true
			}
		}
	}
	return strings.TrimSpace(b.String())
}

func normalizeText(text string) string {
	return strings.Join(strings.Fields(strings.ToLower(strings.TrimSpace(text))), " ")
}

var memoryStopWords = map[string]bool{
	"a": true, "ad": true, "al": true, "alla": true, "alle": true, "anche": true,
	"che": true, "con": true, "da": true, "dal": true, "dalla": true, "dei": true,
	"del": true, "della": true, "di": true, "e": true, "è": true, "gli": true,
	"ha": true, "ho": true, "i": true, "il": true, "in": true, "io": true,
	"la": true, "le": true, "lo": true, "ma": true, "mi": true, "non": true,
	"o": true, "per": true, "piu": true, "più": true, "si": true, "sono": true,
	"su": true, "un": true, "una": true, "uno": true,
}

func tokenizeMemory(s string) []string {
	s = strings.ToLower(s)
	var b strings.Builder
	for _, r := range s {
		if unicode.IsLetter(r) || unicode.IsDigit(r) {
			b.WriteRune(r)
		} else {
			b.WriteByte(' ')
		}
	}
	fields := strings.Fields(b.String())
	out := make([]string, 0, len(fields))
	seen := map[string]bool{}
	for _, f := range fields {
		if len([]rune(f)) < 2 || memoryStopWords[f] || seen[f] {
			continue
		}
		seen[f] = true
		out = append(out, f)
	}
	return out
}

func deriveMemoryTopic(text string) string {
	toks := tokenizeMemory(text)
	if len(toks) > 6 {
		toks = toks[:6]
	}
	if len(toks) == 0 {
		return "nota"
	}
	return strings.Join(toks, " ")
}

func clampConfidence(v float64) float64 {
	if v <= 0 {
		return 1.0
	}
	if v > 1 {
		return 1
	}
	return v
}

func (s *Server) loadMemoryStateLocked() (MemoryState, error) {
	path := s.memoryStatePath()
	b, err := os.ReadFile(path)
	if errors.Is(err, os.ErrNotExist) {
		return MemoryState{Version: 1, Facts: []MemoryFact{}}, nil
	}
	if err != nil {
		return MemoryState{}, err
	}
	var st MemoryState
	if err := json.Unmarshal(b, &st); err != nil {
		return MemoryState{}, fmt.Errorf("memory_state non valido: %w", err)
	}
	if st.Version == 0 {
		st.Version = 1
	}
	return st, nil
}

func (s *Server) saveMemoryStateLocked(st MemoryState) error {
	if err := os.MkdirAll(filepath.Dir(s.memoryStatePath()), 0o755); err != nil {
		return err
	}
	st.Version = 1
	b, err := json.MarshalIndent(st, "", "  ")
	if err != nil {
		return err
	}
	return durableWriteFile(s.memoryStatePath(), b, 0o600)
}

func (s *Server) appendMemoryAuditLocked(line string) {
	path := s.memoryAuditPath()
	_ = os.MkdirAll(filepath.Dir(path), 0o755)
	if _, err := os.Stat(path); errors.Is(err, os.ErrNotExist) {
		header := "# CAPO MEMORY — audit locale\n\nQuesto file registra le lezioni persistenti di CAPO. Le informazioni superate restano visibili per audit; `memory_state.json` contiene lo stato macchina corrente. Questa memoria NON equivale a training dei pesi del modello.\n\n"
		_ = os.WriteFile(path, []byte(header), 0o600)
	}
	f, err := os.OpenFile(path, os.O_APPEND|os.O_WRONLY|os.O_CREATE, 0o600)
	if err != nil {
		return
	}
	defer f.Close()
	_, _ = f.WriteString(line)
}

func (s *Server) pruneInactiveLocked(st *MemoryState) {
	limit := s.cfg.MaxMemoryFacts
	if limit <= 0 {
		limit = 1000
	}
	if len(st.Facts) < limit {
		return
	}
	// Remove oldest inactive facts first. Active knowledge is never silently dropped.
	kept := make([]MemoryFact, 0, len(st.Facts))
	inactiveBudget := len(st.Facts) - limit + 1
	for _, f := range st.Facts {
		if inactiveBudget > 0 && !f.Active {
			inactiveBudget--
			continue
		}
		kept = append(kept, f)
	}
	st.Facts = kept
}

func (s *Server) teachMemory(topic, text, source string, confidence float64) (MemoryEvent, error) {
	topic = normalizeTopic(topic)
	text = strings.TrimSpace(text)
	source = strings.TrimSpace(source)
	if text == "" {
		return MemoryEvent{}, errors.New("testo memoria vuoto")
	}
	if len(text) > 8000 {
		return MemoryEvent{}, errors.New("testo memoria troppo lungo")
	}
	if topic == "" {
		topic = deriveMemoryTopic(text)
	}
	if len(topic) > 200 {
		return MemoryEvent{}, errors.New("topic memoria troppo lungo")
	}
	if source == "" {
		source = "utente"
	}
	confidence = clampConfidence(confidence)

	s.memoryMu.Lock()
	defer s.memoryMu.Unlock()

	st, err := s.loadMemoryStateLocked()
	if err != nil {
		return MemoryEvent{}, err
	}
	now := time.Now().UTC().Format(time.RFC3339)
	s.pruneInactiveLocked(&st)
	normalized := normalizeText(text)
	previousIdx := -1
	for i := range st.Facts {
		if st.Facts[i].Active && normalizeTopic(st.Facts[i].Topic) == topic {
			previousIdx = i
			break
		}
	}
	if previousIdx >= 0 && normalizeText(st.Facts[previousIdx].Text) == normalized {
		st.Facts[previousIdx].Reinforcement++
		st.Facts[previousIdx].UpdatedAt = now
		if confidence > st.Facts[previousIdx].Confidence {
			st.Facts[previousIdx].Confidence = confidence
		}
		if err := s.saveMemoryStateLocked(st); err != nil {
			return MemoryEvent{}, err
		}
		s.appendMemoryAuditLocked(fmt.Sprintf("- %s · **RINFORZO** `%s`: %s _(id %s, x%d)_\n", now, topic, text, st.Facts[previousIdx].ID, st.Facts[previousIdx].Reinforcement))
		return MemoryEvent{Kind: "reinforced", Topic: topic, FactID: st.Facts[previousIdx].ID}, nil
	}

	limit := s.cfg.MaxMemoryFacts
	if limit <= 0 {
		limit = 1000
	}
	if len(st.Facts) >= limit {
		return MemoryEvent{}, fmt.Errorf("limite memoria raggiunto (%d fatti); dimentica o archivia prima di aggiungerne altri", limit)
	}

	id := fmt.Sprintf("mem-%d", time.Now().UTC().UnixNano())
	fact := MemoryFact{
		ID: id, Topic: topic, Text: text, Source: source, Confidence: confidence,
		Reinforcement: 1, CreatedAt: now, UpdatedAt: now, Active: true,
	}
	ev := MemoryEvent{Kind: "learned", Topic: topic, FactID: id}
	supersededAudit := ""
	if previousIdx >= 0 {
		prevID := st.Facts[previousIdx].ID
		prevText := st.Facts[previousIdx].Text
		st.Facts[previousIdx].Active = false
		st.Facts[previousIdx].SupersededBy = id
		st.Facts[previousIdx].SupersededAt = now
		ev.Kind = "superseded"
		ev.PreviousID = prevID
		supersededAudit = fmt.Sprintf("- %s · **SUPERATO** `%s`: ~~%s~~ _(id %s → %s)_\n", now, topic, prevText, prevID, id)
	}
	st.Facts = append(st.Facts, fact)
	if err := s.saveMemoryStateLocked(st); err != nil {
		return MemoryEvent{}, err
	}
	if supersededAudit != "" {
		s.appendMemoryAuditLocked(supersededAudit)
	}
	s.appendMemoryAuditLocked(fmt.Sprintf("- %s · **ATTIVO** `%s`: %s _(fonte: %s; confidenza %.2f; id %s)_\n", now, topic, text, source, confidence, id))
	return ev, nil
}

func (s *Server) forgetMemory(topic string) (MemoryEvent, error) {
	topic = normalizeTopic(topic)
	if topic == "" {
		return MemoryEvent{}, errors.New("topic vuoto")
	}
	s.memoryMu.Lock()
	defer s.memoryMu.Unlock()
	st, err := s.loadMemoryStateLocked()
	if err != nil {
		return MemoryEvent{}, err
	}
	now := time.Now().UTC().Format(time.RFC3339)
	for i := range st.Facts {
		if st.Facts[i].Active && normalizeTopic(st.Facts[i].Topic) == topic {
			st.Facts[i].Active = false
			st.Facts[i].ForgottenAt = now
			st.Facts[i].UpdatedAt = now
			if err := s.saveMemoryStateLocked(st); err != nil {
				return MemoryEvent{}, err
			}
			s.appendMemoryAuditLocked(fmt.Sprintf("- %s · **DIMENTICATO** `%s`: ~~%s~~ _(id %s)_\n", now, topic, st.Facts[i].Text, st.Facts[i].ID))
			return MemoryEvent{Kind: "forgotten", Topic: topic, PreviousID: st.Facts[i].ID}, nil
		}
	}
	return MemoryEvent{}, errors.New("topic attivo non trovato")
}

func memoryScore(queryTokens map[string]bool, queryNorm string, f MemoryFact) float64 {
	if !f.Active {
		return -1
	}
	score := 0.0
	matched := len(queryTokens) == 0 && queryNorm == ""
	topicNorm := normalizeTopic(f.Topic)
	if queryNorm != "" && topicNorm != "" && strings.Contains(queryNorm, topicNorm) {
		score += 5
		matched = true
	}
	for _, tok := range tokenizeMemory(f.Topic + " " + f.Text) {
		if queryTokens[tok] {
			score += 1
			matched = true
		}
	}
	// Confidence, reinforcement and recency may rank relevant memories, but must
	// never create relevance on their own. This prevents unrelated fresh/high-
	// confidence facts from leaking into a targeted recall query.
	if !matched {
		return -1
	}
	score += float64(minInt(f.Reinforcement, 10)) * 0.08
	score += f.Confidence * 0.2
	if t, err := time.Parse(time.RFC3339, f.UpdatedAt); err == nil {
		ageDays := time.Since(t).Hours() / 24
		if ageDays < 7 {
			score += 0.15
		} else if ageDays < 30 {
			score += 0.05
		}
	}
	return score
}

func minInt(a, b int) int {
	if a < b {
		return a
	}
	return b
}

func (s *Server) recallMemory(query string, k int) []MemoryFact {
	if k <= 0 {
		k = 5
	}
	if k > 20 {
		k = 20
	}
	s.memoryMu.Lock()
	defer s.memoryMu.Unlock()
	st, err := s.loadMemoryStateLocked()
	if err != nil {
		return nil
	}
	qTokensSlice := tokenizeMemory(query)
	qTokens := map[string]bool{}
	for _, t := range qTokensSlice {
		qTokens[t] = true
	}
	qNorm := normalizeTopic(query)
	type scored struct {
		fact  MemoryFact
		score float64
	}
	rows := make([]scored, 0)
	for _, f := range st.Facts {
		if !f.Active {
			continue
		}
		sc := memoryScore(qTokens, qNorm, f)
		if len(qTokens) == 0 || sc > 0.2 {
			rows = append(rows, scored{f, sc})
		}
	}
	sort.SliceStable(rows, func(i, j int) bool {
		if rows[i].score == rows[j].score {
			return rows[i].fact.UpdatedAt > rows[j].fact.UpdatedAt
		}
		return rows[i].score > rows[j].score
	})
	if len(rows) > k {
		rows = rows[:k]
	}
	out := make([]MemoryFact, len(rows))
	for i := range rows {
		out[i] = rows[i].fact
	}
	return out
}

func (s *Server) memoryPrompt(query string) (string, int) {
	facts := s.recallMemory(query, 6)
	if len(facts) == 0 {
		return "", 0
	}
	maxChars := s.cfg.MaxMemoryPromptChars
	if maxChars <= 0 {
		maxChars = 5000
	}
	var b strings.Builder
	b.WriteString("MEMORIA PERSISTENTE CAPO — stato corrente verificabile:\n")
	used := 0
	for _, f := range facts {
		line := fmt.Sprintf("- [%s] %s (fonte=%s, confidenza=%.2f, rinforzi=%d, id=%s)\n", f.Topic, f.Text, f.Source, f.Confidence, f.Reinforcement, f.ID)
		if b.Len()+len(line) > maxChars {
			break
		}
		b.WriteString(line)
		used++
	}
	return b.String(), used
}

func (s *Server) activeMemoryCount() int {
	s.memoryMu.Lock()
	defer s.memoryMu.Unlock()
	st, err := s.loadMemoryStateLocked()
	if err != nil {
		return 0
	}
	n := 0
	for _, f := range st.Facts {
		if f.Active {
			n++
		}
	}
	return n
}

func parseMemoryCommand(message string) (kind, topic, text string, ok bool) {
	trimmed := strings.TrimSpace(message)
	lower := strings.ToLower(trimmed)
	prefixes := []struct{ prefix, kind string }{
		{"impara", "teach"}, {"ricorda", "teach"}, {"correggi", "teach"},
	}
	rest := ""
	for _, p := range prefixes {
		match := lower == p.prefix || strings.HasPrefix(lower, p.prefix+" ") || strings.HasPrefix(lower, p.prefix+":") || strings.HasPrefix(lower, p.prefix+"[")
		if match {
			rest = strings.TrimSpace(trimmed[len(p.prefix):])
			kind = p.kind
			break
		}
	}
	if kind == "" {
		return "", "", "", false
	}
	rest = strings.TrimLeft(rest, " :")
	if strings.HasPrefix(rest, "[") {
		if end := strings.Index(rest, "]"); end > 1 {
			topic = strings.TrimSpace(rest[1:end])
			rest = strings.TrimSpace(strings.TrimLeft(rest[end+1:], " :="))
		}
	}
	if topic == "" {
		// Friendly explicit form: "impara: topic = fact".
		if eq := strings.Index(rest, "="); eq > 0 {
			topic = strings.TrimSpace(rest[:eq])
			rest = strings.TrimSpace(rest[eq+1:])
		}
	}
	text = strings.TrimSpace(rest)
	if text == "" {
		return "", "", "", false
	}
	if topic == "" {
		topic = deriveMemoryTopic(text)
	}
	return kind, topic, text, true
}

func (s *Server) handleMemory(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodGet {
		writeJSON(w, http.StatusMethodNotAllowed, map[string]any{"error": "method_not_allowed"})
		return
	}
	query := strings.TrimSpace(r.URL.Query().Get("query"))
	facts := s.recallMemory(query, 20)
	writeJSON(w, http.StatusOK, map[string]any{"count": len(facts), "query": query, "facts": facts})
}

func (s *Server) handleMemoryTeach(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		writeJSON(w, http.StatusMethodNotAllowed, map[string]any{"error": "method_not_allowed"})
		return
	}
	var in MemoryTeachRequest
	if err := json.NewDecoder(http.MaxBytesReader(w, r.Body, 1<<20)).Decode(&in); err != nil {
		writeJSON(w, http.StatusBadRequest, map[string]any{"error": "json_non_valido"})
		return
	}
	ev, err := s.teachMemory(in.Topic, in.Text, in.Source, in.Confidence)
	if err != nil {
		writeJSON(w, http.StatusBadRequest, map[string]any{"error": "memoria_non_salvata", "detail": err.Error()})
		return
	}
	writeJSON(w, http.StatusOK, map[string]any{"ok": true, "event": ev, "weights_trained": false})
}

func (s *Server) handleMemoryForget(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		writeJSON(w, http.StatusMethodNotAllowed, map[string]any{"error": "method_not_allowed"})
		return
	}
	var in MemoryForgetRequest
	if err := json.NewDecoder(http.MaxBytesReader(w, r.Body, 1<<20)).Decode(&in); err != nil {
		writeJSON(w, http.StatusBadRequest, map[string]any{"error": "json_non_valido"})
		return
	}
	ev, err := s.forgetMemory(in.Topic)
	if err != nil {
		writeJSON(w, http.StatusNotFound, map[string]any{"error": "memoria_non_trovata", "detail": err.Error()})
		return
	}
	writeJSON(w, http.StatusOK, map[string]any{"ok": true, "event": ev, "weights_trained": false})
}

func (s *Server) handleMemoryAudit(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodGet {
		writeJSON(w, http.StatusMethodNotAllowed, map[string]any{"error": "method_not_allowed"})
		return
	}
	b, err := os.ReadFile(s.memoryAuditPath())
	if errors.Is(err, os.ErrNotExist) {
		writeJSON(w, http.StatusOK, map[string]any{"audit": "", "path": "capo_data/MEMORY.md"})
		return
	}
	if err != nil {
		writeJSON(w, http.StatusInternalServerError, map[string]any{"error": "audit_non_disponibile"})
		return
	}
	if len(b) > 256*1024 {
		b = b[len(b)-256*1024:]
	}
	writeJSON(w, http.StatusOK, map[string]any{"audit": string(b), "path": "capo_data/MEMORY.md"})
}
